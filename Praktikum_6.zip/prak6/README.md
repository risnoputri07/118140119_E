# 118140016

repo praktikum Web ITERA

Cara insert data:

- isi form input data
- klik tambah

Cara delete data:

- pada baris yang ingin dihapus, klik hapus

Cara update data:

- isi form input data
- klik edit pada baris yang ingin diedit maka data akan terupdate kecuali nim

<?php
$a=20;
$b=5;

echo " bilangan 1 =" .$a;
echo "<br>";
echo " bilangan 2 =" .$b;
echo "<br>";
echo "<br>";
echo "berikut merupakan hasil dari setiap operasi";

echo "<br>";
echo "<br>";
echo "PENJUMLAHAN";
echo "<br>";
echo "operator : +";
echo "<br>";
echo "hasil : ";
echo $a+$b;

echo "<br>";
echo "<br>";
echo "PENGURANGAN";
echo "<br>";
echo "operator : -";
echo "<br>";
echo "hasil : ";
echo $a-$b;

echo "<br>";
echo "<br>";
echo "PERKALIAN";
echo "<br>";
echo "operator : *";
echo "<br>";
echo "hasil : ";
echo $a*$b;

echo "<br>";
echo "<br>";
echo "PEMBAGIAN";
echo "<br>";
echo "operator : /";
echo "<br>";
echo "hasil : ";
echo $a/$b;

echo "<br>";
echo "<br>";
echo "MODULUS";
echo "<br>";
echo "operator : %";
echo "<br>";
echo "hasil : ";
echo $a%$b;
?>